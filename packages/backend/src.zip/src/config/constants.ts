export const REMINDER_SCHEDULE = {
  daily: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
  every_2_days: ["Sunday", "Thursday"],
  every_3_days: ["Sunday", "Tuesday", "Thursday"],
  weekly: ["Sunday"],
};
