// import dailyReminderService from "../services/dailyReminderService";

// (async () => {
//   try {
//     await dailyReminderService.processReminders();
//     console.log("✅ Daily reminders sent successfully");
//   } catch (err) {
//     console.error("❌ Failed to send reminders", err);
//   } finally {
//     process.exit();
//   }
// })();
